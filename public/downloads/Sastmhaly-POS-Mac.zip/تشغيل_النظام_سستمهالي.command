#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR"
echo "===================================================="
echo "       جاري تشغيل سستمهالي - النسخة المكتبية الأوفلاين"
echo "===================================================="
export OFFLINE_MODE=true
export DATABASE_MODE=sqlite
export PORT=3456
open "http://localhost:3456/merchant/pos"
npm run dev -- -p 3456
